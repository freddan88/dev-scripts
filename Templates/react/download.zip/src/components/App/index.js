import React, { Component } from 'react';
import './style.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <h1>ReactApp</h1>
      </div>
    );
  }
}

export default App;